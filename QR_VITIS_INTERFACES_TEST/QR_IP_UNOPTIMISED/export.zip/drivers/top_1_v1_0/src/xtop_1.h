// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2023.2 (64-bit)
// Tool Version Limit: 2023.10
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2023 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef XTOP_1_H
#define XTOP_1_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xtop_1_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
#ifdef SDT
    char *Name;
#else
    u16 DeviceId;
#endif
    u64 Control_BaseAddress;
} XTop_1_Config;
#endif

typedef struct {
    u64 Control_BaseAddress;
    u32 IsReady;
} XTop_1;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XTop_1_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XTop_1_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XTop_1_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XTop_1_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
#ifdef SDT
int XTop_1_Initialize(XTop_1 *InstancePtr, UINTPTR BaseAddress);
XTop_1_Config* XTop_1_LookupConfig(UINTPTR BaseAddress);
#else
int XTop_1_Initialize(XTop_1 *InstancePtr, u16 DeviceId);
XTop_1_Config* XTop_1_LookupConfig(u16 DeviceId);
#endif
int XTop_1_CfgInitialize(XTop_1 *InstancePtr, XTop_1_Config *ConfigPtr);
#else
int XTop_1_Initialize(XTop_1 *InstancePtr, const char* InstanceName);
int XTop_1_Release(XTop_1 *InstancePtr);
#endif

void XTop_1_Start(XTop_1 *InstancePtr);
u32 XTop_1_IsDone(XTop_1 *InstancePtr);
u32 XTop_1_IsIdle(XTop_1 *InstancePtr);
u32 XTop_1_IsReady(XTop_1 *InstancePtr);
void XTop_1_EnableAutoRestart(XTop_1 *InstancePtr);
void XTop_1_DisableAutoRestart(XTop_1 *InstancePtr);

void XTop_1_Set_A_DRAM(XTop_1 *InstancePtr, u64 Data);
u64 XTop_1_Get_A_DRAM(XTop_1 *InstancePtr);
void XTop_1_Set_Q_DRAM(XTop_1 *InstancePtr, u64 Data);
u64 XTop_1_Get_Q_DRAM(XTop_1 *InstancePtr);
void XTop_1_Set_R_DRAM(XTop_1 *InstancePtr, u64 Data);
u64 XTop_1_Get_R_DRAM(XTop_1 *InstancePtr);

void XTop_1_InterruptGlobalEnable(XTop_1 *InstancePtr);
void XTop_1_InterruptGlobalDisable(XTop_1 *InstancePtr);
void XTop_1_InterruptEnable(XTop_1 *InstancePtr, u32 Mask);
void XTop_1_InterruptDisable(XTop_1 *InstancePtr, u32 Mask);
void XTop_1_InterruptClear(XTop_1 *InstancePtr, u32 Mask);
u32 XTop_1_InterruptGetEnabled(XTop_1 *InstancePtr);
u32 XTop_1_InterruptGetStatus(XTop_1 *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
